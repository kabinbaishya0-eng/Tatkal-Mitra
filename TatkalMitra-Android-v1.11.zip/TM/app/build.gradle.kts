plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tatkalmitra.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.tatkalmitra.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 12
        versionName = "1.11"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
