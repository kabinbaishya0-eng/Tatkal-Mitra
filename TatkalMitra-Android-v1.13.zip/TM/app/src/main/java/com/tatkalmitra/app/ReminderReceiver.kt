package com.tatkalmitra.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("tatkal", "Tatkal reminders", NotificationManager.IMPORTANCE_HIGH)
            )
            builder = Notification.Builder(context, "tatkal")
        } else {
            builder = Notification.Builder(context)
        }
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = builder
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(intent.getStringExtra("t") ?: "Tatkal Mitra")
            .setContentText(intent.getStringExtra("x") ?: "")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }
}
