# Tatkal Mitra (Android) - v1.2
The app UI runs inside a WebView (app/src/main/assets/index.html). Reminders use native Android alarms.

## Option A: Android Studio (simplest)
1. Unzip, then File > Open the TatkalMitra folder. Let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Copy app/build/outputs/apk/debug/app-debug.apk to your phone and install it (allow "install unknown apps").

## Option B: GitHub builds it for you (free)
1. Create a repo on github.com. Upload everything in this folder with "Add file > Upload files".
2. The hidden .github folder may not upload from a phone. In that case: Add file > Create new file, type
   .github/workflows/build.yml as the name, and paste the contents of that file from this zip.
3. Open the Actions tab > Build APK > Run workflow. In about 5 minutes download the artifact "TatkalMitra-debug-apk" and install the APK.

## What changed in v1.2 (new "ticket" design)
- UI restyled to a clean, premium look: soft grey canvas, white rounded cards, black pill buttons, light-weight route codes with a dotted train line, week date-strip picker, pill chips, floating tab bar. Logo and app icon unchanged.
- Journeys are ticket cards (train, class badge, big station codes, date, passengers, Edit / Prepare). Prepare is a step-by-step card list. Review shows journey and passenger tables.
- Bug fix: Delete buttons (journey, passenger, group, history record) did nothing in v1.0/1.1 because the confirm dialog broke its own onclick attribute. Fixed and tested.
- Tab order now matches the spec: Home, Journeys, Passengers, Prepare, Profile.
- Saved data format unchanged, so existing installs keep their data.

## What changed in v1.1 (redesign)
- New logo (rail track running to a clock), new adaptive launcher icon with themed/monochrome layer, new notification icon. Source art: design/logo.svg.
- Whole UI rebuilt: station-board look, departure-board countdown, ticket-style journey cards, timeline-style Prepare screen, centre "Prepare" tab, bottom sheets. Colours unchanged.
- No Google Fonts call any more (works fully offline). Uses Android's built-in condensed font for headings.
- Hero photo carousel removed; 4 photos kept for splash, onboarding and a home tip (page is ~0.5 MB smaller).
- Fixes: countdown showed "--" after returning to Home; toggling a passenger on the journey form jumped the page to the top.
- Android: new Bridge.setBars() colours the status and navigation bars per screen and theme.
- Your saved data (localStorage key "tm1") is unchanged, so existing installs keep their journeys and passengers.

## Notes
- Debug APK, not for the Play Store. Not compile-tested by the author: tell me any build error text and I will fix it.
- Data is stored privately on the device. Reminders are rescheduled each time the app opens (alarms are lost after a phone restart until then).
- Independent assistant. Not affiliated with Indian Railways or IRCTC.

## v1.3
- New launcher logo: express-train front with saffron stripe and a Tatkal clock badge (adaptive + monochrome + notification icons). Source: design/logo.svg

## v1.4
- New logo: layered tickets with a Tatkal lightning bolt (design/logo.svg)
- New two-tone icon set
- Button effects: glossy primary buttons with sheen, touch ripple, light haptic, glass bottom bar with animated active pill

## v1.5
- In-app calendar (replaces the system date dialog) with quick picks and Tatkal-opening hint
- Station picker redesigned: pinned search, popular chips, card rows with code badges
- New route and status-badge icons; nav bar gives the active tab extra room so labels fit

## v1.6
- New typographic wordmark: TATKAL / MITRA as a coach on rails, with pantograph and catenary wire, a signal-lamp I, wheels and a livery stripe. Colour, reversed and mono SVGs in design/
- New T monogram launcher icon (adaptive, themed and notification variants) and in-app logo
- Splash screen now uses the wordmark

## v1.7
- IRCTC now opens inside the app (BrowserActivity) in mobile mode: mobile Chrome user agent, no desktop site, close/reload bar, back navigates inside IRCTC, no JavaScript bridge exposed to the site
- App logo replaced with the supplied TATKAL MITRA typographic logo: splash, in-app badge, launcher (adaptive + themed) icons

## v1.8
- IRCTC opens in English by default (English-India locale and Accept-Language sent with the first request). IRCTC remembers a language you pick yourself.

## v1.9
- The IRCTC language pop-up is answered automatically: the in-app browser taps "English" once on the "select your preferred language" prompt (and nowhere else).

## v1.10
- Saved passengers now flow into journeys automatically: new journeys start with the passengers ticked on the Passengers tab (or all saved passengers), and journeys that have none pick them up once. You can still change them in Edit journey.

## v1.11
- Removed the automatic English tap on IRCTC (it can trigger IRCTC bot protection and cause "Access Denied"). Choose the language yourself once.
- In-app IRCTC browser: new Reset button (clears this browser's IRCTC data and reloads) and one automatic reset+retry when IRCTC answers 403 Access Denied.

## v1.12
- IRCTC in-app browser no longer sends the WebView "X-Requested-With" header (Chrome does not send it; IRCTC edge protection can answer Access Denied to it). Adds the androidx.webkit dependency.
