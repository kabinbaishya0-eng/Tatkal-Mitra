/* Tatkal Mitra - fills YOUR saved journey and passenger details into the official IRCTC page.
 * It never touches login, password, captcha, OTP, payment or the Book/Continue buttons.
 * Injected only on irctc.co.in by BrowserActivity. window.__TM_DATA is set just before this runs. */
(function () {
  if (!/(^|\.)irctc\.co\.in$/.test(location.hostname)) return;
  var D = window.__TM_DATA;
  if (!D) return;
  if (window.__tmFill) { window.__tmFill.data = D; window.__tmFill.reset(); return; }

  var st = window.__tmFill = { data: D, done: {}, busy: false, reset: function () { st.done = {}; } };
  var CLS = { "1A": "(1A)", "2A": "(2A)", "3A": "(3A)", "3E": "(3E)", "SL": "(SL)", "2S": "(2S)", "CC": "(CC)", "EC": "(EC)" };

  function q(s, r) { return (r || document).querySelector(s); }
  function qa(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function vis(e) { return !!(e && (e.offsetWidth || e.offsetHeight || e.getClientRects().length)); }
  async function waitFor(fn, ms) {
    var t = Date.now();
    while (Date.now() - t < ms) { var r = fn(); if (r) return r; await sleep(120); }
    return null;
  }
  function fire(el, type) { el.dispatchEvent(new Event(type, { bubbles: true })); }
  function setVal(el, v) {
    var proto = el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
    fire(el, "input"); fire(el, "change");
  }
  function clickEl(el) {
    ["mousedown", "mouseup", "click"].forEach(function (t) {
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
    });
  }
  function banner(msg) {
    var b = document.getElementById("tm-banner");
    if (!b) {
      b = document.createElement("div"); b.id = "tm-banner";
      b.style.cssText = "position:fixed;left:8px;right:8px;bottom:12px;z-index:2147483647;background:#0D1B4C;color:#fff;" +
        "font:600 13px/1.4 sans-serif;padding:10px 14px;border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.3);border-left:4px solid #F26A00";
      document.body.appendChild(b);
    }
    b.textContent = "Tatkal Mitra: " + msg;
    clearTimeout(b._t); b._t = setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 9000);
  }

  async function fillStation(sel, code) {
    var inp = q(sel + " input"); if (!inp || !vis(inp)) return false;
    inp.focus(); clickEl(inp); setVal(inp, code);
    var items = await waitFor(function () {
      var a = qa(".ui-autocomplete-items li, .p-autocomplete-items li, .p-autocomplete-panel li, ul[role=listbox] li").filter(vis);
      return a.length ? a : null;
    }, 3000);
    if (!items) return false;
    var re = new RegExp("-\\s*" + code + "\\s*$", "i");
    var m = items.filter(function (i) { return re.test(i.textContent.trim()); })[0] || items[0];
    clickEl(m);
    await sleep(250);
    return true;
  }

  async function fillDate(iso) {
    var inp = q("#jDate input"); if (!inp || !vis(inp)) return false;
    var p = iso.split("-"), txt = p[2] + "/" + p[1] + "/" + p[0];
    inp.focus(); clickEl(inp); setVal(inp, txt);
    inp.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", keyCode: 13, bubbles: true }));
    await sleep(300);
    // if the calendar popup is open, click the day as a fallback
    var cal = qa(".ui-datepicker, .p-datepicker").filter(vis)[0];
    if (cal) {
      var day = qa("td a, td span", cal).filter(function (e) { return e.textContent.trim() === String(+p[2]) && !/disabled|other-month/.test(e.className + e.parentNode.className); })[0];
      if (day) clickEl(day);
      await sleep(200);
    }
    inp.blur();
    return true;
  }

  async function pickDropdown(sel, wanted) {
    var dd = q(sel); if (!dd || !vis(dd)) return false;
    var trg = q(".ui-dropdown-trigger, .p-dropdown-trigger, .ui-dropdown-label, .p-dropdown-label", dd) || dd;
    clickEl(trg);
    var items = await waitFor(function () {
      var a = qa("li[role=option], .ui-dropdown-item, .p-dropdown-item").filter(vis);
      return a.length ? a : null;
    }, 2000);
    if (!items) return false;
    var w = wanted.toUpperCase();
    var m = items.filter(function (i) { return i.textContent.trim().toUpperCase() === w; })[0] ||
            items.filter(function (i) { return i.textContent.toUpperCase().indexOf(w) >= 0; })[0];
    if (!m) { clickEl(trg); return false; }
    clickEl(m); await sleep(250);
    return true;
  }

  async function fillSearch() {
    var d = st.data, ok = [], miss = [];
    (await fillStation("#origin", d.from) ? ok : miss).push("From");
    (await fillStation("#destination", d.to) ? ok : miss).push("To");
    (await fillDate(d.date) ? ok : miss).push("Date");
    (await pickDropdown("#journeyClass", CLS[d.cls] || d.cls) ? ok : miss).push("Class");
    (await pickDropdown("#journeyQuota", d.quota) ? ok : miss).push("Quota");
    banner((ok.length ? "filled " + ok.join(", ") + ". " : "") + (miss.length ? "Please set " + miss.join(", ") + " yourself. " : "") + "Then tap Search.");
  }

  function gCode(g) { g = (g || "").toLowerCase(); return g[0] === "f" ? "F" : g[0] === "t" ? "T" : "M"; }
  function bCode(b) {
    b = (b || "").toLowerCase();
    if (/side.*lower/.test(b)) return "SL";
    if (/side.*upper/.test(b)) return "SU";
    if (/lower/.test(b)) return "LB";
    if (/middle/.test(b)) return "MB";
    if (/upper/.test(b)) return "UB";
    return "";
  }
  function setSelect(sel, code) {
    if (!sel) return;
    var opt = qa("option", sel).filter(function (o) { return o.value === code || o.value === "string:" + code || o.value.replace(/^\d+:\s*/, "") === code; })[0];
    if (opt) setVal(sel, opt.value);
  }

  async function fillPassengers() {
    var pax = st.data.pax || [];
    if (!pax.length) return;
    var names = function () { return qa("input[placeholder='Name']").filter(vis); };
    var tries = 0;
    while (names().length < pax.length && tries++ < 8) {
      var add = qa("span, a, button").filter(function (e) { return vis(e) && /^\+?\s*add passenger$/i.test(e.textContent.trim()); })[0];
      if (!add) break;
      clickEl(add); await sleep(350);
    }
    var N = names(), A = qa("input[formcontrolname='passengerAge']").filter(vis),
        G = qa("select[formcontrolname='passengerGender']").filter(vis),
        B = qa("select[formcontrolname='passengerBerthChoice']").filter(vis), n = 0;
    for (var i = 0; i < pax.length && i < N.length; i++) {
      setVal(N[i], pax[i].name); N[i].blur();
      if (A[i]) setVal(A[i], String(pax[i].age));
      setSelect(G[i], gCode(pax[i].gender));
      setSelect(B[i], bCode(pax[i].berth));
      n++; await sleep(150);
    }
    banner("filled " + n + " of " + pax.length + " passenger(s). Check them, enter the captcha yourself, then continue.");
  }

  async function tick() {
    if (st.busy) return; st.busy = true;
    try {
      if (!st.done.search && q("#origin input") && vis(q("#origin input")) && !qa(".modal.show, .ui-dialog, .p-dialog").filter(vis).length) {
        st.done.search = true; await fillSearch();
      }
      if (!st.done.pax && qa("input[placeholder='Name']").filter(vis).length) {
        st.done.pax = true; await fillPassengers();
      }
    } catch (e) { /* never break the page */ }
    st.busy = false;
  }
  setInterval(tick, 1200); tick();
})();
