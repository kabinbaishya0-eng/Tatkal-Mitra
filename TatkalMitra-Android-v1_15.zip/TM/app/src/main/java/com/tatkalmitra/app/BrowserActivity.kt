package com.tatkalmitra.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.util.Locale

/**
 * In-app browser used for the official IRCTC handoff.
 * - Mobile layout: a mobile Chrome user agent and a normal viewport, never the desktop site.
 * - No JavaScript bridge is attached, so the loaded site cannot call into Tatkal Mitra.
 * - Tatkal Mitra never reads or stores anything typed on the site.
 * - Optional autofill: when opened with a "fill" payload, it types the user's own saved journey and passenger
 *   details into the IRCTC form (irctc.co.in only). It never touches login, password, captcha, OTP or payment.
 */
class BrowserActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var hostText: TextView
    private var startUrl = ""
    private var autoReset = false
    private var fillJson: String? = null
    private val navy = Color.parseColor("#0D1B4C")
    private val orange = Color.parseColor("#F26A00")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun barButton(label: String, desc: String, onTap: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            contentDescription = desc
            isClickable = true
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            setOnClickListener { onTap() }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ask websites for English (India) so IRCTC opens in English by default.
        Locale.setDefault(Locale("en", "IN"))
        window.statusBarColor = navy
        window.navigationBarColor = Color.WHITE

        val start = intent.getStringExtra("url") ?: "https://www.irctc.co.in/nget/train-search"
        if (!start.startsWith("https://")) { finish(); return }
        startUrl = start
        fillJson = intent.getStringExtra("fill")

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }

        // ---- top bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(navy)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        }
        bar.addView(barButton("✕", "Close and return to Tatkal Mitra") { finish() })
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = "Official IRCTC site"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        })
        hostText = TextView(this).apply {
            setTextColor(Color.parseColor("#B8C2E6"))
            textSize = 12f
            maxLines = 1
        }
        titleCol.addView(hostText)
        bar.addView(titleCol)
        if (fillJson != null) {
            bar.addView(TextView(this).apply {
                text = "Fill"
                setTextColor(orange)
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                contentDescription = "Fill my saved details again"
                isClickable = true
                layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
                setOnClickListener { injectFill(true) }
            })
        }
        bar.addView(TextView(this).apply {
            text = "Reset"
            setTextColor(Color.parseColor("#B8C2E6"))
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            contentDescription = "Clear IRCTC data in this browser and reload"
            isClickable = true
            layoutParams = LinearLayout.LayoutParams(dp(60), dp(52))
            setOnClickListener { resetAndReload(true) }
        })
        bar.addView(barButton("↻", "Reload") { web.reload() })
        root.addView(bar)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(orange)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3))
        }
        root.addView(progress)

        // ---- web view, mobile mode
        web = WebView(this)
        web.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        root.addView(web)
        setContentView(root)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(false) // target=_blank links open in this same view
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.useWideViewPort = true           // honour the site's own mobile viewport
        s.loadWithOverviewMode = false     // do not shrink to a desktop-width page
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.textZoom = 100
        // Present as mobile Chrome (drop the WebView markers that make some sites serve a desktop or app-less layout).
        s.userAgentString = s.userAgentString.replace("; wv", "").replace(" Version/4.0", "")
        // Stop the WebView adding "X-Requested-With: <this app's package>" to every request. Chrome never sends it,
        // and IRCTC's edge protection can answer "Access Denied" when it sees it.
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
                WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, emptySet())
            }
        } catch (e: Exception) {
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.setDownloadListener { url, _, _, _, _ -> openExternal(url) }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: return false
                if (scheme == "https" || scheme == "http") return false
                return openExternal(request.url.toString()) // upi:, intent:, tel:, mailto: ...
            }

            override fun onPageFinished(view: WebView, url: String?) {
                updateHost(url)
                injectFill(false)
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: android.webkit.WebResourceResponse) {
                // IRCTC's edge protection can answer 403 "Access Denied" for a flagged visit; clear the saved visit once and retry.
                if (request.isForMainFrame && errorResponse.statusCode == 403) {
                    if (!autoReset) {
                        autoReset = true
                        resetAndReload(false)
                    } else {
                        // Still refused: show the same official page in Chrome's overlay window instead.
                        openInChromeTab()
                    }
                }
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    val u = request.url.toString().replace("\"", "")
                    val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
                        "<body style='font-family:sans-serif;text-align:center;padding:56px 24px;color:#0D1B4C'>" +
                        "<h2>Can’t reach this page</h2><p style='color:#666'>Check your internet connection and try again.</p>" +
                        "<p><a href=\"$u\" style='display:inline-block;background:#0D1B4C;color:#fff;padding:14px 28px;border-radius:30px;text-decoration:none'>Try again</a></p></body></html>"
                    view.loadDataWithBaseURL(u, html, "text/html", "utf-8", u)
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) android.view.View.VISIBLE else android.view.View.INVISIBLE
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@BrowserActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@BrowserActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
        }

        updateHost(start)
        web.loadUrl(start, mapOf("Accept-Language" to "en-IN,en;q=0.9"))
    }

    /** Runs the autofill script on irctc.co.in pages only. The script waits for the form, so it is safe to call early. */
    private fun injectFill(manual: Boolean) {
        val json = fillJson ?: return
        val host = try { Uri.parse(web.url ?: "").host ?: "" } catch (e: Exception) { "" }
        if (host != "irctc.co.in" && !host.endsWith(".irctc.co.in")) {
            if (manual) Toast.makeText(this, "Open the IRCTC page first", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val js = assets.open("irctc_fill.js").bufferedReader().use { it.readText() }
            web.evaluateJavascript("window.__TM_DATA=" + json + ";" + js, null)
            if (manual) Toast.makeText(this, "Filling your saved details…", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
    }

    /** Clears cookies, site data and cache of this in-app browser (signs out of IRCTC here) and reloads. */
    private fun resetAndReload(showToast: Boolean) {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        android.webkit.WebStorage.getInstance().deleteAllData()
        web.clearCache(true)
        if (showToast) Toast.makeText(this, "IRCTC data cleared", Toast.LENGTH_SHORT).show()
        web.loadUrl(startUrl, mapOf("Accept-Language" to "en-IN,en;q=0.9"))
    }

    /** Opens the page in a Chrome Custom Tab (Chrome shown over this app; its close button returns here). */
    private fun openInChromeTab() {
        try {
            val tab = CustomTabsIntent.Builder()
                .setToolbarColor(navy)
                .setShowTitle(true)
                .setShareState(CustomTabsIntent.SHARE_STATE_OFF)
                .build()
            tab.launchUrl(this, Uri.parse(startUrl))
            finish()
        } catch (e: Exception) {
            openExternal(startUrl)
        }
    }

    private fun updateHost(url: String?) {
        val host = try { Uri.parse(url ?: "").host ?: "" } catch (e: Exception) { "" }
        hostText.text = if (host.isEmpty()) "" else "🔒 $host"
    }

    private fun openExternal(url: String): Boolean {
        try {
            val i = if (url.startsWith("intent:")) Intent.parseUri(url, Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
