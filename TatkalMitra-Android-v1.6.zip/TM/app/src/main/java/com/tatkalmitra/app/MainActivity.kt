package com.tatkalmitra.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0D1B4C")
        window.navigationBarColor = Color.parseColor("#0D1B4C")
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0D1B4C"))
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.scheme == "http" || url.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    return true
                }
                return false
            }
        }
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.tmBack && window.tmBack()") { result ->
            if (result != "true") super@MainActivity.onBackPressed()
        }
    }
}

class Bridge(private val activity: Activity) {
    private val prefs = activity.getSharedPreferences("tm", Context.MODE_PRIVATE)
    private val alarms = activity.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pending(id: String, title: String, text: String): PendingIntent {
        val intent = Intent(activity, ReminderReceiver::class.java)
        intent.data = Uri.parse("tm://reminder/$id")
        intent.putExtra("t", title)
        intent.putExtra("x", text)
        return PendingIntent.getBroadcast(
            activity, id.hashCode(), intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    @JavascriptInterface
    fun openUrl(url: String) {
        if (url.startsWith("https://")) {
            activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    @JavascriptInterface
    fun requestPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            activity.runOnUiThread {
                activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }

    @JavascriptInterface
    fun schedule(id: String, atMillis: String, title: String, text: String) {
        val at = atMillis.toLongOrNull() ?: return
        if (at <= System.currentTimeMillis()) return
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(id, title, text))
        val ids = prefs.getStringSet("ids", emptySet())!!.toMutableSet()
        ids.add(id)
        prefs.edit().putStringSet("ids", ids).apply()
    }

    /** Lets the page match the system bars to the current screen and theme. */
    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun setBars(status: String, nav: String, darkIcons: Boolean) {
        activity.runOnUiThread {
            try {
                val w = activity.window
                w.statusBarColor = Color.parseColor(status)
                w.navigationBarColor = Color.parseColor(nav)
                var f = w.decorView.systemUiVisibility
                f = if (darkIcons) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                if (Build.VERSION.SDK_INT >= 26) {
                    f = if (darkIcons) f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
                }
                w.decorView.systemUiVisibility = f
            } catch (e: Exception) {
            }
        }
    }

    @JavascriptInterface
    fun clearAll() {
        val ids = prefs.getStringSet("ids", emptySet()) ?: emptySet()
        for (id in ids) alarms.cancel(pending(id, "", ""))
        prefs.edit().remove("ids").apply()
    }
}
